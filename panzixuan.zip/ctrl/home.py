def get(request, response):
    response.redirect('blog')
    