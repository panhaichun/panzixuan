install_path = '/home/haichun/panzx'
ctx_path = ''

ds_database = install_path + '/db.sql3'
log_file = install_path + '/log/pzx.log'

port = 8000
encoding = 'UTF-8'

cookie_path = '/'
cookie_domain = 'panzx.com'

site_name = '梓萱家园'
